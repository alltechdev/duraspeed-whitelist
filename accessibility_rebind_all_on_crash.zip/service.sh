#!/system/bin/sh

while true; do
  ENABLED_SERVICES=$(settings get secure enabled_accessibility_services)

  IFS=':'; for svc in $ENABLED_SERVICES; do
    if dumpsys accessibility | grep -A 10 "Crashed services" | grep -q "$svc"; then
      settings put secure enabled_accessibility_services ""
      settings put secure enabled_accessibility_services "$ENABLED_SERVICES"
      settings put secure enabled_accessibility_services ""
      settings put secure enabled_accessibility_services "$ENABLED_SERVICES"
      break
    fi
  done

  sleep 0.5
done
